H@N demo ROMs (original homebrew, free to share)

HAN-DEMO.gb   Game Boy
HAN-DEMO.gbc  Game Boy Color (same demo, in color)
HAN-DEMO.nes  NES (mapper 4 / MMC3)

Scenes: intro, wireframe H@N, spinning cubes, raster wobble + sine scroller, input test.
A = next scene, B = music on/off, START = input test.
The input test goes back to the intro after about 13 seconds without a button press.

Copy them to /Roms/GB, /Roms/GBC and /Roms/NES on the SD card (or use "Send games over USB"
on https://hackatnight.com/HAN-CYD-GBC/). They also run in other emulators and on real hardware
flash carts. Source: https://github.com/hackatnight/HAN-CYD-GBC/tree/main/tools/demos
Font: Adafruit GFX 5x7 font, BSD license (see FONT-LICENSE.txt in the source folder).
